<?php
	require_once('getGcell.php');
	
	
	
	$maxValue="{-maxValue-}";
	$minValue="{-minValue-}";
	
	$title="{-title-}";
	
	$graphType="{-graphType-}";
	$typeForColumn=Array();
	$ignore=Array();
	// $ignore[]='sleet';
	$backGroundColor="{-bgColor-}";
	$autoScale="{-autoScale-}"=="false"?false:true;
	$lineSize={-lineSize-};
	$dotSize={-dotSize-};
	$a=gListTable("{-url-}","{-ignoreColumns-}",'');
	
	// Below here should never change
	
	
	if($autoScale) {
		$maxValue=-9999999;
		$minValue=-$maxValue;	
	}
	
	$colors=Array("#2E578B",
				  "#5D9548",
				  "#E7A03C",
				  "#BC2C2F",
				  "#6F3C78",
				  "#7C7F7F",
				  "#41689B",
				  "#6EA35A",
				  "#EAAC54",
				  "#C54345",
				  "#814F8A",
				  "#8D9090");
	
	
	

	
	$legends=$a["_headers"];
	unset($a["_headers"]);
	
	include_once( 'open-flash-chart.php' );
	$g = new graph();
	$g->title( $title, '{font-size: 20px; color: #736AFF}' );
	for ($i=1;$i<count($legends);$i++) {
		
		// Start out with Sane Default
		$thisLegend=$legends[$i];
		$thisColor=$colors[$i%count($colors)];
		$thisLineSize=$lineSize;
		$thisDotSize=$dotSize;
		
		if ($thisLegend==null)  {
			continue ; // if we should ignore then do so
		}
		$data=$a[$thisLegend] ;
		if ($autoScale) {
			if (max($data)>$maxValue)
				$maxValue=max($data);
			if (min($data)<$minValue)
				$minValue=min($data);
		}
		$g->set_data($data );
		
		$thisColor=$colors[$i%count($colors)];
		
		switch($graphType) {
			case "bar" :
				$g->bar(70,$thisColor,$thisLegend,12);
				break;
			case "bar_glass" :
				$g->bar_glass(70,$thisColor,$thisColor,$thisLegend,12);
				break;
			case "area_hollow" :
				$g->area_hollow($thisLineSize,$thisDotSize,$thisColor,70,$thisLegend,12);
				break;
			case "line_dot" :
				$g->line_dot($thisLineSize,$thisDotSize,$thisColor,$thisLegend,12);
				break;
			case "line" :
			default:
				$g->line($thisLineSize,$thisColor,$thisLegend,12);;
		}
	}
	
	$g->set_x_labels($a[$legends[0]]);
	
	$g->set_y_max( $maxValue );
	$g->set_y_min($minValue);
	
	
	
	echo $g->render();
	
	?>